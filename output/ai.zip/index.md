# Home - FHIR Implementation Guide for PUBLIC Testing v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://fhir.osbornemj.com/ig/ImplementationGuide/fhir.osbornemj.ig | *Version*:0.1.0 |
| Draft as of 2026-04-13 | *Computable Name*:FHIROsbornemjIG |

## FHIR Implementation Guide Test Harness

## Overview

This is an Implementation Guide (IG) test harness for testing Australian content, based on good work by [Daniel Foulkes](https://www.linkedin.com/in/daniel-foulkes/) (see Acknowledgments below to access the original repo). It provides a basic structure with a set of commonly used base FHIR profiles that can be readily modified and/or extended to meet the project requirements. The repository for [this build](https://fhir-osbornemj-com.onrender.com/) is located at [fhir-osbornemj-com](https://github.com/mjosborne1/fhir-osbornemj-com) This version of the template includes dependencies on AU Base (v6.0.0) and AU Core (v2.0.0).

### License

Distributed under the MIT License. See [LICENSE.txt](https://au-ig-template.healthinfoservices.site/LICENSE.txt) for more information.

### Acknowledgments

* [FHIR Shorthand FSH](https://build.fhir.org/ig/HL7/fhir-shorthand/overview.html)
* [AU Base Implementation Guide](https://build.fhir.org/ig/hl7au/au-fhir-base/index.html)
* [AU Core Implementation Guide](https://build.fhir.org/ig/hl7au/au-fhir-core/index.html)
* [HealthInfoServices Australia template](https://au-ig-template.healthinfoservices.site/)
* [Daniel Foulkes](https://www.linkedin.com/in/daniel-foulkes/)

([back to top](#readme-top))

